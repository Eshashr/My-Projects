/*
The Main class should handle running the point of sale system for the pizza restaurant.

You should allow the user to input multiple orders each with multiple pizzas. Pizzas can be either traditional or deep dish, and have a variety of toppings. I suggest you have the user enter a string like "pm", where each letter stands for a topping, e.g. "pm" would be pepperoni and mushrooms.

Before you beginning, you add 4 toppings to your Restaurant's toppings ArrayList (using the Restaurant method addTopping). Remember Restaurant doesn't need to be instantiated, as there is only one, e.g. use Restaurant.addTopping("pepperoni", "1.29"). There are 4 toppings available. "pepperoni" and "extra cheese" are 1.29, "green peppers" and "mushrooms" are 0.99. 

I recommend creating multiple static methods in this Main class for specific purposes. One might handle reading in a single pizza. One might handle reading in an order of pizzas (and in that process calling the previous method). Break up the task like that.

After the user is done inputting all of their orders, the program should print out all of the orders (using the Restaurant's printOrders method) and the price of the priciest order (found using the Restaurant's priciestOrder method).

If you are working in a group (max size 3), add an extra feature of your choice for each person in the group beyond the first. An extra feature might be a new type of pizza or the ability to find the average price of a pizza.  
*/

import java.util.Scanner;

public class Main {
	static void menuPrinter(int menu){
		switch(menu){
			case 1:
				System.out.println("1. Add new Order");
				System.out.println("2. Confirm Orders");
				System.out.println("3. Exit.");
				break;
			case 2:
				System.out.println("1. Add Pizza to your current order");
				System.out.println("2. Exit to add a new order instead.");
				break;
			case 3:
				System.out.println("1. Traditional Pizza");
				System.out.println("2. Deep Dish Pizza");
				System.out.println("3. FireWood Pizza");
				System.out.println("4. Exit.");
				break;
			case 4:
				System.out.println("1. Pepperoni ");
				System.out.println("2. Extra Cheese");
				System.out.println("3. Green Peppers");
				System.out.println("4. Mushrooms");
				System.out.println("5. Olives");
				System.out.println("6. Exit.");
			case 5:
				break;
			default:
		}
	}

	static Order orderCreator(){
		Order order = new Order();
		boolean run = true;
		while(run){
			menuPrinter(2);
			Scanner obj = new Scanner(System.in);
			System.out.print("Enter your choice: ");
			int choice = obj.nextInt();
			switch(choice){
				case 1:
					Pizza tempPizza = pizzaOrderTaker();
					if(tempPizza!= null){
						order.addPizza(tempPizza);
					}else{
						run = false;
					}
					break;
				case 2:
					run = false;
					break;
				default:
					System.out.println("The choice you entered is invalid");
			}
		}
		if (order.noOfPizza() == 0){
			return null;
		}
		return order;
	}

	static Pizza pizzaOrderTaker(){
		Pizza currentPizza = null;
		boolean run = true;
		while(run){
			menuPrinter(3);
			Scanner obj = new Scanner(System.in);
			System.out.print("Enter your choice: ");
			int choice = obj.nextInt();
			switch(choice){
				case 1:
					currentPizza = new TraditionalPizza();
					run = false;
					break;
				case 2:
					currentPizza = new DeepDishPizza();
					run = false;
					break;
				case 3:
					currentPizza = new FireWoodPizza();
					run = false;
					break;
				case 4:
					return null;
				default:
					System.out.println("The choice you entered is invalid");
			}
		}
		return toppingAdder(currentPizza);
	}

	static Pizza toppingAdder(Pizza pizza){
		menuPrinter(4);
		Scanner obj = new Scanner(System.in);
		System.out.print("Enter your choice (Note: Enter 1,2,3 to add the 3 toppings no: 1 2 and 3: ");
		String choice = obj.nextLine();
		String toppingName;
		switch(choice){
			case "5": //instantly exit if exit is chosen
				return pizza;
			default:
				String[] arrOfTopping = choice.split(",");//splitting topping string into an array
				for(int i = 0; i<arrOfTopping.length; i++){
					String currentTopping = arrOfTopping[i].replaceAll("\\s+","");//removing whitespaces
					switch (currentTopping){
						case "1":
							toppingName = "pepperoni";
							break;
						case "2":
							toppingName = "extra cheese";
							break;
						case "3":
							toppingName = "green peppers";
							break;
						case "4":
							toppingName = "mushrooms";
							break;
						case "5":
							toppingName = "olives";
							break;
						default:
							toppingName = "none"; //in cases where user inputs invalid topping reference

					}
					if(toppingName != "none"){
						pizza.addTopping(Restaurant.getTopping(toppingName));
					}
				}
				return pizza;
		}
	}

    public static void main(String[] args) {
		Restaurant.addTopping("pepperoni", 1.29);
		Restaurant.addTopping("extra cheese", 1.29);
		Restaurant.addTopping("green peppers", 0.99);
		Restaurant.addTopping("mushrooms", 0.99);
		Restaurant.addTopping("olives", 1.15);

		Scanner obj = new Scanner(System.in);

		boolean run = true;
		while(run == true){
			menuPrinter(1);
			System.out.print("Enter your choice: ");
			int choice = obj.nextInt();

			switch(choice){
				case 1:
					Order tempOrder = orderCreator();
					if(tempOrder!=null){
						Restaurant.addOrder(tempOrder);
					}
					break;
				case 2:
					run = false;
					if (Restaurant.noOfOrders() !=0) {
						Restaurant.printOrders();
						System.out.println("The priciest order is: " + Restaurant.priciestOrder());
					}else{
						System.out.println("No orders placed!");
						System.out.println("Thank you for visiting!");
					}
					break;
				case 3:
					run = false;
					System.out.println("No orders placed!");
					System.out.println("Thank you for visiting!");
					break;
				default:
					System.out.println("The choice you entered is invalid");
			}

		}

    }
}