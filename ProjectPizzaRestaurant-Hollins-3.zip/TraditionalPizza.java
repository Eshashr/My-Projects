public class TraditionalPizza extends Pizza {
    double bPrice = 8.99;
    public double basePrice(){
        return bPrice;
    }

    public String toString(){
        return "Traditional Pizza - A traditional pizza consisting of the most ancient Italian Flavors";
    }
}

/*
The TraditionalPizza class should be a public class that is a subclass of Pizza. 

The class should implement the basePrice method as defined in the Pizza class. The base price of a TraditionalPizza is 8.99.

The class should have a public toString method that returns a String description of the Pizza.
*/
