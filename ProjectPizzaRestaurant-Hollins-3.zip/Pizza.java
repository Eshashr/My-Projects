
/*
The Pizza class should be a public abstract class that describes a generic pizza.

The class should have a protected instance variable, toppings, that is an ArrayList of Topping instances that are toppings on this particular pizza. As a protected instance variable it will be accessible by subclasses but not external classes.

The class should have a void method addTopping that takes a Topping instance and adds it to the toppings ArrayList.

The class should have an abstract method basePrice that returns a double that is the base price of the the pizza. This method will be implemented by the subclasses of Pizza, TraditionalPizza and DeepDishPizza.

The class should have a private toppingsPrice method that returns a double that is the sum of the prices of the toppings on the pizza.

The class should have a totalPrice method that returns a double that is the total price of the pizza, which is the sum of the basePrice and the toppingsPrice.
*/
import java.util.ArrayList;

public abstract class Pizza {
    ArrayList<Topping> toppings = new ArrayList<Topping>();

    void addTopping(Topping topping){
        toppings.add(topping);
    }

    public abstract double basePrice();

    private double toppingsPrice(){
        double totalPrice = 0;
        for(int i = 0; i<toppings.size();i++){
            totalPrice += toppings.get(i).price;
        }
        return totalPrice;
    }

    double totalPrice(){
        return (this.toppingsPrice() + this.basePrice());
    }

}