public class FireWoodPizza extends Pizza {
    double bPrice = 9.99;
    public double basePrice(){
        return bPrice;
    }

    public String toString(){
        return "FireWoodPizza - A Firewood Pizza prepared in our own custom crafted oven";
    }
}